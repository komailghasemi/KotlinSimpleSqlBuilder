package com.daya.clientapp.query

enum class CastTo {
    INTEGER
}